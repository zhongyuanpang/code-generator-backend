package com.pzy.codegenerator.domain;

import lombok.Data;

@Data
public class Table {
}
